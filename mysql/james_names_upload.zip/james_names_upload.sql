SELECT * from names 
INSERT into names (name, created_at, updated_at) VALUES ('James Fern', NOW(), NOW())	1 row(s) affected	0.000 sec
INSERT into names (name, created_at,updated_at) 
VALUES 
('Monika Jasper', NOW(), NOW()),
('Terrible Idea', NOW(), NOW());